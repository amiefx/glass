<template>
  <v-tab to="/admin/invoice/approvals">
    <v-badge color="green" content="6"> POs </v-badge>
  </v-tab>
</template>

<script>
export default {};
</script>

<style>
</style>
