<template>
  <div>
      <v-row>
              <p>this is dashboard</p>
          <br>
      <p>{{ $t('select')}}</p>
      </v-row>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
