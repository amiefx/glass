<template>
  <div>
      <v-row>
      <v-col cols="12" sm="6" md="4" lg="3">
        <v-alert text prominent color="success" icon="mdi-cash-multiple">
          <h3>5568</h3>
          Cash
        </v-alert>
      </v-col>
      <v-col cols="12" sm="6" md="4" lg="3">
        <v-alert text prominent color="success" icon="mdi-cash-multiple">
          <h3>5568</h3>
          Cash
        </v-alert>
      </v-col>
      <v-col cols="12" sm="6" md="4" lg="3">
        <v-alert text prominent color="success" icon="mdi-cash-multiple">
          <h3>5568</h3>
          Cash
        </v-alert>
      </v-col>
      <v-col cols="12" sm="6" md="4" lg="3">
        <v-alert text prominent color="success" icon="mdi-cash-multiple">
          <h3>5568</h3>
          Cash
        </v-alert>
      </v-col>
      <v-col cols="12" sm="6" md="4" lg="3">
        <v-alert text prominent color="success" icon="mdi-cash-multiple">
          <h3>5568</h3>
          Cash
        </v-alert>
      </v-col>
      </v-row>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
