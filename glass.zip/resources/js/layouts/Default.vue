<template>
  <div>
      <div>
          <slot />
      </div>
  </div>
</template>

<script>
export default {
    components: {
    }
}
</script>

<style>

</style>
